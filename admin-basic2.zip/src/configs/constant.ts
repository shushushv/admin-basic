export const API_DEV = '/api';

export const API_PROD = '';

export const CANCEL_REQUEST_MESSAGE = 'cancel request';