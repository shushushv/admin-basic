import { Layout } from "antd";
import React from "react";
import { Fragment } from "react";

const PublicLayout: React.FC<any> = () => {
  return <Fragment>
    <Layout>
      {/* <Sider></Sider>
      <div>
        <Header
      </div> */}
    </Layout>
  </Fragment>;
}

export default PublicLayout;